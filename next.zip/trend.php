<?php
$ball=$_GET['ball'];
$ball_1= str_replace (" ","_",$ball);

$ball_3= str_replace ("#","",$ball);;
$ball_2=urlencode ($ball_3);
?>
<html>
<head>
<title>Advanced Search</title>

</head>
<body bgcolor="#222">

<div id="heading" style="text-align:center;color:#fc6;font-size:55px;padding-top:30px;"> Trending <font style="color:#369;font-size:55;"> Bubbles</font></div>
<img style="position:absolute;margin-top:-370px;margin-left:50px" src="bubble.png"/>

<div id="search" style="padding-top:20px;padding-left:50px" >
<iframe  src="gooyobi.php?news=<?php echo $ball?>" height="500px" width="770px"  frameborder="0" scrolling="no"></iframe>  
</div>
<div id="wikipedia" style="float:right;margin-top: -477px; padding-right: 60px;">
<div id="strip" style="	font-size:15px;background : #336699;height:23px;padding-top:6px;padding-left:6px;width: 350px;border-radius : 7px;color:white"><strong> Wikipedia</strong></div>
<div style="padding-top:10px;">
<iframe  src="http://baba-job.appspot.com/Wikipedia?name=<?php echo $ball_1?>" height="700" width="350" frameborder="1" scrolling="no" > </iframe>    
</div>
</div>
<br>
<div id="yotube" style="float:right;padding-top:30px;padding-right:40px;">
<div id="strip" style="	font-size:15px;background : #336699;height:23px;padding-top:6px;padding-left:6px;width: 344px;border-radius : 7px;color:white"><strong> YouTube</strong></div>
<div style="padding-top:10px;">
<iframe  class="youtube-player" type="text/html" width="350" height="280" src="http://www.youtube.com/embed/UF8uR6Z6KLc" frameborder="0"></iframe>	
</div>
</div>
<br>
<div id="trends" style="float:left;padding-top:10px;padding-left:50px;">
<div id="strip" style="	font-size:15px;background : #336699;height:23px;padding-top:6px;padding-left:6px;width: 344px;border-radius : 7px;color:white"><strong> Google Trends</strong></div>
<div style="padding-top:10px;">
<iframe style="" src="http://www.gmodules.com/ig/ifr?url=http://www.google.com/ig/modules/trends_gadget.xml&amp;source=imag&amp;up_is_init=true&amp;up_cur_term=<?php echo $ball_2?>&amp;up_date=mtd&amp;up_region=all" style="padding:10px;" width="350" height="278" frameborder="0" scrolling="no"></iframe>
</div>
</div>

<br>

</body>
</html>
